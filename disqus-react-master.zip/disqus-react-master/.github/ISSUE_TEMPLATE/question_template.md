---
name: Question
about: Ask a question about the package
---

<!-- Make sure to check the [FAQ](https://github.com/disqus/disqus-react/wiki/Frequently-Asked-Questions) and the [Disqus Knowledge base](https://help.disqus.com/) before submitting a new question. -->

